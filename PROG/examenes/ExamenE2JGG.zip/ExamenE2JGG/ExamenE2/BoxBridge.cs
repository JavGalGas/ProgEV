﻿namespace ExamenE2
{
    public class BoxWin : IBox
    {
        private int _boxPosition = 1;
        public int BoxPosition => _boxPosition;


        public BoxWin(int boxPosition)
        {
            _boxPosition = boxPosition;
        }

        public void ApplyEffect(Game game)
        {
            game.VisitPlayers(player =>
            {
                if (player.PlayerPosition == _boxPosition)
                {
                    if (_boxPosition == 27)
                    {
                        player.SetPlayerPosition(53, game);
                    }
                    else
                    {
                        player.SetPlayerPosition(27, game);
                    }
                    player.SimulatePlayer(game);
                }
            });
        }
    }
}