﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ExamenE2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //TestDB();
        }

        private void TestDB()
        {
            string connectionString = "Data Source=test.db";
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();

                // Crear una tabla
                string createTableQuery = "CREATE TABLE IF NOT EXISTS empleados (id INTEGER PRIMARY KEY, nombre TEXT, edad INTEGER)";
                using (var command = new SqliteCommand(createTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }

                // Insertar datos
                string insertQuery = "INSERT INTO empleados (nombre, edad) VALUES (@nombre, @edad)";
                using (var command = new SqliteCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@nombre", "Juan Pérez");
                    command.Parameters.AddWithValue("@edad", 30);
                    command.ExecuteNonQuery();
                }

                // Leer datos
                string selectQuery = "SELECT * FROM empleados";
                using (var command = new SqliteCommand(selectQuery, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine($"ID: {reader["id"]}, Nombre: {reader["nombre"]}, Edad: {reader["edad"]}");
                    }
                }
            }
        }

        private void GooseGameDB()
        {
            string connectionString = "Data Source=test.db";
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();

                // Crear una tabla
                string createTableQuery = "CREATE TABLE IF NOT EXISTS partidas (id INTEGER PRIMARY KEY, partida TEXT)";
                using (var command = new SqliteCommand(createTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }

                // Insertar datos
                string insertQuery = "INSERT INTO partidas (partida) VALUES (@partida)";
                using (var command = new SqliteCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@partida", "Juan Pérez");
                    command.ExecuteNonQuery();
                }

                // Leer datos
                string selectQuery = "SELECT * FROM empleados";
                using (var command = new SqliteCommand(selectQuery, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine($"ID: {reader["id"]}, Nombre: {reader["nombre"]}, Edad: {reader["edad"]}");
                    }
                }
            }

        }

        private void CreateGame(object sender, RoutedEventArgs e)
        {
            Player p = new PlayerNormal("A");
            Player p2 = new PlayerQuick("B", Utils.GetRandomBetween(1,3));
            Player p3 = new PlayerCheater("C");

            Game g = new Game();
            g.AddPlayer(p);
            g.AddPlayer(p2);
            g.AddPlayer(p3);
            Player winner = g.Simulate();
            
            Console.WriteLine($"{winner.Name} is the winner");
        }
        //pasar lista posicion jugadores, paso a json, añado a la BD
        //hacer lo contrario para leerlo
    }
}
