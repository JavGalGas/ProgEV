﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej2
{
    public class Ejercicio2
    {
        public static int[] Merge(int[] array1, int[] array2)
        {
            if (array1 == null || array1.Length < 0)
                throw new ArgumentException();
            if (array2 == null || array2.Length < 0)
                throw new ArgumentException();

            int[] result = new int[array1.Length + array2.Length];

            int i = 0;
            int j = 0;

            for (int k = 0; k < result.Length; k++)
            {
                if (i >= array1.Length)
                {
                    for (int l = j; l < array2.Length; l++)
                        result[l] = array2[l];
                    break;
                }
                if (j >= array2.Length)
                {
                    for (int l = i; l < array2.Length; l++)
                        result[l] = array1[l];
                    break;
                }
                else
                {
                    if (array1[i] < array2[j])
                    {
                        result[k] = array1[i];
                        i++;
                    }
                    else
                    {
                        result[k] = array2[j];
                        j++;
                    }
                }       
            }

            return result;        
        }
    }
}
