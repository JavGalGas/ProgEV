﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej4
{
    public interface IPool<T>
    {
        T? First {  get; }
        T? Last { get; }

        T[] ToArray();
        void AddElement(T element);
        void RemoveElement();

        Pool<T> Clone();

    }
}
