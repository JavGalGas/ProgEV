﻿namespace TPVLib
{
    public class Invoice
    {
        

    }
}
