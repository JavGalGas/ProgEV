﻿namespace TPVLib
{
    public class Header
    {
        public long Id { get; set; }
        public DateTime Date { get; set; }
        public string BarCode { get; set; } = "";
    }

}