﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen2EVA_JGG
{
    public class Rect2D
    {
        public double x, y, x2, y2;

    }
}
