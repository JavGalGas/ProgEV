﻿namespace Examen2EVA_JGG
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}