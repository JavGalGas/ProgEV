﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen2EVA_JGG
{
    public class Color
    {
        private double R, G, B, A;

    }
}
