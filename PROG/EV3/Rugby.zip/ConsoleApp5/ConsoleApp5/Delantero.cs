﻿
namespace ConsoleApp5
{
    public class Delantero : Jugador
    {
        public Delantero(string name, Equipo equipo, Coordenadas posicion) : base(name, equipo, posicion)
        {
        }

        public override void EjecutarTurno(ICampo campo)
        {
        }
    }
}
