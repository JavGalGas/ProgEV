﻿namespace ConsoleApp5
{
    public class Dementor : Personaje
    {
        public Dementor(Coordenadas posicion) : base(posicion)
        {
        }

        public override void EjecutarTurno(ICampo campo)
        {
        }
    }
}
