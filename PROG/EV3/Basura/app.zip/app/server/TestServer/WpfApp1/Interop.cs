﻿namespace WpfApp1
{
    public class Login
    {
        public string username { get; set; }
        public string password { get; set; }
    }

    public class Session
    {
        public string token { get; set; }
    }
}
