﻿using System.Text.Json;

namespace ndupcopy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DuplicateCleaner.RunProgram(args);
        }
    }
}
