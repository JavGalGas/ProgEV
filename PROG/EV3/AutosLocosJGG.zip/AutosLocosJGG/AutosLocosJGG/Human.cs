﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutosLocosJGG
{
    public class Human : Driver
    {
        public override double GetVelocityExtra()
        {
            return 0.0;
        }
    }
}
